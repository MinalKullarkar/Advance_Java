package com.jspiders.cardekho_case_study.entity;

public class Car {
	private int car_id;
	private String name;
	private String model;
	private String Brand;
	private String fuel_type;
	private double price;
	
	
	
	

	public int getCar_id() {
		return car_id;
	}





	public void setCar_id(int car_id) {
		this.car_id = car_id;
	}





	public String getName() {
		return name;
	}





	public void setName(String name) {
		this.name = name;
	}





	public String getModel() {
		return model;
	}





	public void setModel(String model) {
		this.model = model;
	}





	public String getBrand() {
		return Brand;
	}





	public void setBrand(String brand) {
		Brand = brand;
	}





	public String getFuel_type() {
		return fuel_type;
	}





	public void setFuel_type(String fuel_type) {
		this.fuel_type = fuel_type;
	}





	public double getPrice() {
		return price;
	}





	public void setPrice(double price) {
		this.price = price;
	}





	public static void main(String[] args) {
		
	}
}
